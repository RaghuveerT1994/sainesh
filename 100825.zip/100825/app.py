import pandas as pd, io, math
from flask import *
# from flask_paginate import Pagination, get_page_parameter



app=Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] =0

@app.route("/",methods=['POST','GET'])
def homepage():
       return render_template('Homepage.HTML')

@app.route("/",methods=['POST','GET'])
def home():
        # df=pd.read_excel("data.xlsx")
        # records=df.to_dict(orient="records")
        # columns=list(df.columns)
        return render_template("Homepage.html")

@app.route("/home1",methods=['POST','GET'])

def home1():
        df=pd.read_excel("data.xlsx")
        df.insert(0, "S.No", range(1, len(df) + 1))
        df ["Joining date"]=[str(i)[:10] for i in df ["Joining date"]]
        df ["Billing start date"]=[str(i)[:10] for i in df ["Billing start date"]]
        data = df.values.tolist()
        records=df.to_dict(orient="records")
        columns=list(df.columns)
        page = int(request.args.get('page', 1))
        per_page = 5
        start = (page - 1) * per_page
        end = start + per_page
        
        total_pages = math.ceil(len(data) / per_page)
        paginated_data = data[start:end]
        print(paginated_data)
        return render_template("index.html",columns=columns
                               ,page = page,
                               data = paginated_data,
                               total_pages = total_pages, nrows = len(data))

@app.route("/Projects",methods=['POST','GET'])
def Projects():
        df=pd.read_excel("data.xlsx")
        df.insert(0, "S.No", range(1, len(df) + 1))
        cols_to_get = ["S.No", "Project name" ]
        
        valid_cols = [c for c in cols_to_get if c in df.columns]

        subset_df = df[valid_cols]
        subset_df = subset_df.drop_duplicates()
        records=subset_df.to_dict(orient="records")
        columns= valid_cols
        return render_template("Projects.html",records=records,columns=columns,nrows=len(records))

@app.route("/billing",methods=['POST','GET'])
def billing():
        df=pd.read_excel("data.xlsx",parse_dates=True)
        df.insert(0, "S.No", range(1, len(df) + 1))
        df ["Billing start date"]=[str(i)[:10] for i in df ["Billing start date"]]
        cols_to_get = ["S.No", "Project name","Employee ID","Name","Billing start date","Billing rate (GDP)"]

        valid_cols = [c for c in cols_to_get if c in df.columns]
        subset_df = df[valid_cols]
        records=subset_df.to_dict(orient="records")
        columns= valid_cols
        return render_template("billing.html",records=records,columns=columns,nrows=len(records))

@app.route("/render_insert",methods=['POST','GET'])
def render_insert():
    return render_template("insert.html")

@app.route("/download",methods=['POST','GET'])
def download():
    return send_file("data.xlsx",as_attachment=True)

@app.route("/Get_template",methods=['POST','GET'])
def Get_template():
    df = pd.read_excel('data.xlsx')
    headers = df.columns.tolist()
    print(headers)
    headers_df = pd.DataFrame([headers])
    output = io.BytesIO()
    headers_df.to_excel(output, index= False, header= False, engine= 'openpyxl')
    output.seek(0)
    return send_file(output , as_attachment= True,download_name="headers.xlsx", 
                     mimetype= "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     conditional= False)
    

@app.route("/upload",methods=['POST','GET'])
def upload():
    return render_template("Upload.html")

@app.post('/view')
def view():

    # Read the File using Flask request
    file = request.files['file']
    # save file in local directory
#     file.save(file.filename)

    # Parse the data as a Pandas DataFrame type
    data = pd.read_excel(file)
    d =  pd.read_excel('data.xlsx')
    data = pd.concat([d,data])
    data.to_excel("data.xlsx",index=False)

    # Return HTML snippet that will render the table
        #     return data.to_html()
    return render_template('Upload.html')

@app.route("/process_insert",methods=['POST','GET'])
def process_insert():
       df=pd.read_excel("data.xlsx")
       a=[str(i) for i in request.form.values()]
       df1=pd.DataFrame([{
        "Project name":a[0],
       "Employee ID": a[1],
       "Name" :a[2],
       "Joining date": a[3],
       "Billing start date": a[4],
       "Division": a[5],
       "Subdivision": a[6],
       "Billing rate (GDP)": a[7]
       
   }])
       print(df1)
       df1=pd.concat([df,df1],ignore_index=True)
       try:
            df1["Joining date"]=[str(i)[:10] for i in df["Joining date"]]
            df1["Billing start date"]=[str(i)[:10] for i in df["Billing start date"]]
       except:
            pass  
       df1.to_excel("data.xlsx",index=False)
       return render_template("insert.html")

if __name__ == '__main__':
        app.run(host='0.0.0.0',port=8090,use_reloader=False,debug=False)
        # ui.run()